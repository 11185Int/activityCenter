var app = getApp()

Page({
    onLoad: function (option) {
        console.log('onLoad')
        // if (wx.getStorageSync('isRegistered')) {
        //     wx.redirectTo({
        //         url: "/pages/index/index"
        //     })
        // }
        // app.globalData.thirdA_session = wx.getStorageSync('third_session')
        // app.getUserInfo(this.getSession)
    }
})